#!/usr/bin/env python3
"""Instala Cly Local v2 sem depender de texto exato do prompt antigo.
É deliberadamente conservador: valida tudo antes de gravar e salva backups.
"""
from pathlib import Path
from datetime import datetime
import re
import shutil
import sys

root = Path.cwd()
base = root / 'backend/src/services'
service, quota, local = (base / x for x in ('ai.service.ts','cly-quota.service.ts','cly-local.ts'))
source = Path(__file__).resolve().parent / 'cly-local.ts'
for p in (service, quota, source):
    if not p.is_file(): sys.exit(f'ERRO: não achei {p}. Execute na raiz do projeto.')
s, q = service.read_text(encoding='utf-8'), quota.read_text(encoding='utf-8')
newlocal = source.read_text(encoding='utf-8')
s2, q2 = s, q

def one_replace(label, pattern, replacement, current, flags=0):
    result, count = re.subn(pattern, lambda _: replacement, current, count=1, flags=flags)
    if count != 1: sys.exit(f'ERRO: não identifiquei {label} (correspondências: {count}). Nenhuma alteração efetuada.')
    return result

if "from './cly-local'" not in s2:
    s2 = one_replace('importação de cly-provider', r"import\s*\{\s*callProvider\s*,\s*isConfigured\s*\}\s*from\s*['\"]\./cly-provider['\"];", "import { generateClyLocal } from './cly-local';", s2)
    s2 = one_replace('status da Cly', r"get\s+status\s*\(\)\s*\{\s*return\s*\{[\s\S]*?\}\s*;\s*\}\s*,", "get status() { return { configured: true, provider: 'Cly Local', features: { gerarProposta: true, criarMensagem: true, melhorarDescricao: true } }; },", s2)
    # Sem depender da formatação/aspas da mensagem antiga.
    s2 = one_replace('bloqueio do provedor', r"^[ \t]*if\s*\(\s*!isConfigured\(\)\s*\)\s*throw\s+new\s+AppError\([^;]*\);[ \t]*\n", '', s2, flags=re.M)
    s2 = one_replace('mapa de tarefas antigo', r"^[ \t]*const\s+tasks\s*=\s*\{[^}]*\}\s*;[ \t]*\n", '', s2, flags=re.M)
    # Troca a expressão completa desde a declaração até o fim da instrução;
    # o prompt pode conter backticks, JSON.stringify e quebras de linha.
    s2 = one_replace('chamada ao provedor', r"const\s+suggestion\s*=\s*await\s+callProvider\([\s\S]*?\);", "const suggestion = generateClyLocal(action, text);", s2)
    s2 = s2.replace("source: 'ai'", "source: 'template'")
else:
    if 'generateClyLocal(action, text)' not in s2:
        sys.exit('ERRO: instalação local diferente da esperada. Nenhuma alteração feita.')

if 'callProvider(' in s2 or 'isConfigured()' in s2:
    sys.exit('ERRO: ligação antiga com a OpenAI permaneceu em ai.service.ts; nada alterado.')

# Regras: apenas planos realmente conhecidos recebem uso.
old_limit = "const paid = plan !== 'free'; const limit = paid ? (plan === 'pro_max' ? 150 : 50) : 3;"
new_limit = "const paid = plan === 'pro' || plan === 'pro_max'; const limit = paid ? (plan === 'pro_max' ? 150 : 50) : 0;"
if old_limit in q2: q2 = q2.replace(old_limit, new_limit, 1)
elif new_limit not in q2: sys.exit('ERRO: limite de uso diferente do esperado. Nada alterado.')
old_block = 'blocked: paid ? used >= limit : Boolean(row.blocked_until && new Date(row.blocked_until) > now),'
new_block = 'blocked: !paid || used >= limit,'
if old_block in q2: q2 = q2.replace(old_block, new_block, 1)
elif new_block not in q2: sys.exit('ERRO: bloqueio de uso diferente do esperado. Nada alterado.')
if "'AI_PLAN_REQUIRED'" not in q2:
    marker = "     if (view.consentRequired) throw new AppError('Confirme o envio do texto ao provedor antes de usar a Cly.', 403, 'AI_CONSENT_REQUIRED');"
    if marker not in q2: sys.exit('ERRO: reserva de cota diferente do esperado. Nada alterado.')
    q2 = q2.replace(marker, "     if (!['pro', 'pro_max'].includes(plan)) throw new AppError('A Cly esta disponivel nos planos Pro e Pro Plus.', 403, 'AI_PLAN_REQUIRED', view);\n" + marker, 1)
q2 = q2.replace('Confirme o envio do texto ao provedor antes de usar a Cly.', 'Confirme o uso da Cly antes de continuar.')
q2 = q2.replace('Seu limite da Cly foi atingido. Confira o horario de liberacao.', 'Seu limite mensal da Cly foi atingido.')
if not all(x in q2 for x in (new_limit,new_block,"'AI_PLAN_REQUIRED'")):
    sys.exit('ERRO: verificação de proteção por plano falhou. Nada alterado.')

# Copiar o arquivo sem mudar a interface ou as integrações de pagamento.
changes = [(service,s,s2),(quota,q,q2),(local,local.read_text(encoding='utf-8') if local.exists() else None,newlocal)]
if all(before == after for _,before,after in changes):
    print('Cly Local 2.0 já está instalada. Sem alterações.'); sys.exit(0)
backup = root / ('backup-cly-local-final-' + datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
backup.mkdir()
for path, before, after in changes:
    if before is not None and before != after: shutil.copy2(path, backup / path.name)
for path, before, after in changes:
    if before != after: path.write_text(after, encoding='utf-8')
print('SUCESSO: Cly Local 2.0 instalada!')
print('Backup dos arquivos anteriores:', backup)
print('Nenhum deploy foi realizado.')
