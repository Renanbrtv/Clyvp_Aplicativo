/**
 * Integration tests (test DB ONLY):
 *   DB_HOST=127.0.0.1 DB_PORT=3318 DB_NAME=clyvo_cly_test NODE_ENV=test \
 *   ... node --import tsx src/scripts/welcome-integration.ts
 */
import assert from 'node:assert/strict';
import { createApp } from '../app';
import { closePool, execute } from '../config/database';
import { env } from '../config/env';

async function main() {
  if (!env.isTest || env.DB_HOST !== '127.0.0.1' || env.DB_PORT !== 3318 || env.DB_NAME !== 'clyvo_cly_test') {
    throw new Error('Teste autorizado somente em 127.0.0.1:3318/clyvo_cly_test.');
  }
  const server = createApp().listen(0, '127.0.0.1');
  const ids: number[] = [];
  try {
    await new Promise<void>((resolve, reject) => {
      if (server.listening) return resolve();
      server.once('listening', resolve);
      server.once('error', reject);
    });
    const address = server.address();
    if (!address || typeof address === 'string') throw new Error('Servidor sem porta');
    const base = `http://127.0.0.1:${address.port}/api`;
    let token = '';

    async function request(method: string, path: string, body?: unknown) {
      const response = await fetch(`${base}${path}`, {
        method,
        headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: body === undefined ? undefined : JSON.stringify(body),
      });
      return { status: response.status, data: (await response.json()) as any };
    }

    async function register() {
      const email = `welcome.${Date.now()}.${Math.floor(Math.random() * 999999)}@test.invalid`;
      const password = 'TesteBemVindo@2026';
      token = '';
      const response = await request('POST', '/auth/register', { name: 'Teste Bem Vindo', email, password });
      assert.equal(response.status, 201, JSON.stringify(response.data));
      ids.push(response.data.data.user.id);
      token = response.data.data.tokens.accessToken;
      return { email, password };
    }

    // Conta nova: pendente ate o final das configuracoes.
    const { email, password } = await register();
    let me = await request('GET', '/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.data.data.welcome.pending, true);
    assert.equal(me.data.data.welcome.marketConfigured, false);
    console.log('OK: conta nova marcada para boas-vindas');

    let done = await request('POST', '/auth/welcome-complete');
    assert.equal(done.status, 400);
    console.log('OK: nao ignora onboarding obrigatorio');

    const onboard = await request('POST', '/auth/onboarding', {
      sellsType: 'servicos', mainGoal: 'organizar_clientes',
    });
    assert.equal(onboard.status, 200);
    done = await request('POST', '/auth/welcome-complete');
    assert.equal(done.status, 400);
    console.log('OK: nao ignora etapa do marketplace');

    const market = await request('POST', '/market/preferences', {
      intent: 'organizar_negocio', acceptRules: false,
    });
    assert.equal(market.status, 200, JSON.stringify(market.data));
    me = await request('GET', '/auth/me');
    assert.equal(me.data.data.welcome.marketConfigured, true);
    console.log('OK: preserva configuracao de marketplace');

    done = await request('POST', '/auth/welcome-complete');
    assert.equal(done.status, 200, JSON.stringify(done.data));
    done = await request('POST', '/auth/welcome-complete');
    assert.equal(done.status, 200, 'Conclusao idempotente');
    me = await request('GET', '/auth/me');
    assert.equal(me.data.data.welcome.pending, false);
    console.log('OK: conclusao no backend e idempotencia');

    token = '';
    const login = await request('POST', '/auth/login', { email, password });
    assert.equal(login.status, 200);
    token = login.data.data.tokens.accessToken;
    me = await request('GET', '/auth/me');
    assert.equal(me.data.data.welcome.pending, false);
    console.log('OK: segundo acesso nao repete boas-vindas');

    // Simula conta antiga: nenhuma linha na tabela nova.
    await register();
    await execute('DELETE FROM clyvo_welcome WHERE user_id=?', [ids[ids.length - 1]]);
    me = await request('GET', '/auth/me');
    assert.equal(me.data.data.welcome.pending, false);
    console.log('OK: conta antiga sem registro segue normal');

    console.log('TODOS OS TESTES HTTP DE BOAS-VINDAS APROVADOS');
  } finally {
    try {
      for (const id of ids) await execute('DELETE FROM users WHERE id=?', [id]);
    } finally {
      server.closeAllConnections();
      await new Promise<void>((resolve) => server.close(() => resolve()));
      await closePool();
    }
  }
}

main().catch((error) => { console.error('TESTE FALHOU:', error); process.exitCode = 1; });
