-- Nova tabela exclusivamente para novas contas. Nenhum usuario antigo e inserido aqui.
-- Aplicar antes de ativar o backend que consulta este estado.
CREATE TABLE IF NOT EXISTS clyvo_welcome (
  user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  completed_at DATETIME(3) NULL DEFAULT NULL,
  CONSTRAINT fk_clyvo_welcome_user FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
