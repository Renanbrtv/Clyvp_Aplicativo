import { useEffect, useState } from 'react';
import { useEvent } from 'expo';
import { Redirect, useRouter } from 'expo-router';
import { useWindowDimensions, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useVideoPlayer, VideoView } from 'expo-video';

import { useAuth } from '../src/features/auth/auth-context';
import { authApi } from '../src/shared/api/auth.api';
import { Button, Logo } from '../src/shared/components';
import { theme, useThemeMode, createThemedStyles } from '../src/shared/theme';
import { welcomeVideoSource, welcomeVideoAspectRatio } from '../src/features/welcome/video-source';
import { shouldShowWelcomeFallback } from '../src/features/welcome/video-logic';

/** A etapa so e concluida por uma acao do usuario, nunca pelo fim do video. */
export default function BoasVindasScreen() {
  useThemeMode();
  const { status, user, account, reload } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width, height } = useWindowDimensions();
  const [submitting, setSubmitting] = useState(false);
  const [requestError, setRequestError] = useState('');
  const [timedOut, setTimedOut] = useState(false);

  const player = useVideoPlayer(welcomeVideoSource, (instance) => {
    instance.muted = true;
    instance.loop = false;
    if (welcomeVideoSource) instance.play();
  });
  const { status: videoStatus } = useEvent(player, 'statusChange', { status: player.status });
  const failed = shouldShowWelcomeFallback(Boolean(welcomeVideoSource), videoStatus, timedOut);

  useEffect(() => {
    if (!welcomeVideoSource || videoStatus === 'readyToPlay' || videoStatus === 'error') return;
    const timer = setTimeout(() => setTimedOut(true), 12000);
    return () => clearTimeout(timer);
  }, [videoStatus]);

  const availableHeight = Math.max(150, height - insets.top - insets.bottom - 164);
  const frameHeight = Math.min(availableHeight, (width - 44) / welcomeVideoAspectRatio);
  const frameWidth = Math.min(width - 44, frameHeight * welcomeVideoAspectRatio);

  async function handleContinue() {
    if (submitting) return;
    setSubmitting(true);
    setRequestError('');
    try {
      await authApi.completeWelcome();
      await reload();
      router.replace('/(tabs)');
    } catch (error) {
      setRequestError(error instanceof Error ? error.message : 'Nao foi possivel concluir. Tente novamente.');
    } finally {
      setSubmitting(false);
    }
  }

  if (status === 'carregando') return <View style={styles.root} />;
  if (status !== 'autenticado') return <Redirect href="/(auth)/login" />;
  if (user && !user.onboardingCompleted) return <Redirect href="/onboarding" />;
  if (account?.welcome?.pending && !account.welcome.marketConfigured) return <Redirect href="/mercado/comecar" />;
  if (!account?.welcome?.pending) return <Redirect href="/(tabs)" />;

  return (
    <View style={[styles.root, { paddingTop: insets.top + 8, paddingBottom: insets.bottom + 12 }]}>
      <View style={styles.videoSpace}>
        {failed ? (
          <View style={styles.fallback} accessibilityRole="text">
            <Logo size={72} />
            <Text style={styles.fallbackTitle}>Boas-vindas ao Clyvo!</Text>
            <Text style={styles.fallbackText}>Seu espaço para organizar clientes, oportunidades e propostas.</Text>
          </View>
        ) : (
          <VideoView
            player={player}
            nativeControls={false}
            contentFit="contain"
            style={{ width: frameWidth, height: frameHeight }}
            accessibilityLabel="Vídeo de boas-vindas do Clyvo"
          />
        )}
      </View>

      <View style={styles.footer}>
        <Text style={styles.help}>Tudo pronto para começar sua jornada!</Text>
        {requestError ? <Text style={styles.error} accessibilityRole="alert">{requestError}</Text> : null}
        <Button label="Acessar meu painel" iconRight="arrow-right" loading={submitting} onPress={() => void handleContinue()} />
      </View>
    </View>
  );
}

const styles = createThemedStyles(() => ({
  root: { flex: 1, backgroundColor: theme.colors.background },
  videoSpace: { flex: 1, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', paddingHorizontal: 12 },
  fallback: { alignItems: 'center', justifyContent: 'center', paddingHorizontal: 26, gap: 14 },
  fallbackTitle: { ...theme.typography.h1, color: theme.colors.primary, textAlign: 'center' },
  fallbackText: { ...theme.typography.body, color: theme.colors.textSecondary, textAlign: 'center' },
  footer: { paddingHorizontal: theme.screenPadding, gap: 12, paddingTop: 6 },
  help: { ...theme.typography.body, color: theme.colors.textSecondary, textAlign: 'center' },
  error: { ...theme.typography.caption, color: theme.colors.danger, textAlign: 'center' },
}));
