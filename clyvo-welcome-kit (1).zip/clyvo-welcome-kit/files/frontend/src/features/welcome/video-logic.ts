/** A falha de decodificacao, ausencia de asset ou demora excessiva nunca bloqueia o botao. */
export function shouldShowWelcomeFallback(hasVideoSource: boolean, videoStatus: string, timedOut: boolean): boolean {
  return !hasVideoSource || videoStatus === 'error' || timedOut;
}
