// Atualizado automaticamente pelo instalador quando o MP4 for fornecido.
// Nao use uma imagem estatica como se fosse o video original.
export const welcomeVideoSource: number | null = null;
// Ajuste este valor caso o video original nao seja vertical (9:16).
export const welcomeVideoAspectRatio = 9 / 16;
