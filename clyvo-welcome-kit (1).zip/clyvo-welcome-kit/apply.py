#!/usr/bin/env python3
"""Apply the Clyvo welcome-video feature to a dedicated Git worktree.

No production access, no database operations, no git commits. All text patches
are validated in-memory before any file is written.
"""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
from pathlib import Path

KIT = Path(__file__).resolve().parent / "files"
p = argparse.ArgumentParser()
p.add_argument("repo", help="Absolute path to feature branch worktree")
p.add_argument("--video", type=Path, help="Optional original MP4 (not a screenshot)")
args = p.parse_args()
ROOT = Path(args.repo).resolve()

if not (ROOT / "frontend/package.json").is_file() or not (ROOT / "backend/src/services/auth.service.ts").is_file():
    raise SystemExit("PAREI: pasta destino nao parece ser a raiz do Clyvo.")
branch = subprocess.check_output(["git", "-C", str(ROOT), "branch", "--show-current"], text=True).strip()
if not branch.startswith("feat/"):
    raise SystemExit(f"PAREI: branch '{branch}'. Use uma worktree em branch feat/ isolada.")

updates: dict[Path, str] = {}

def edit(relative: str, old: str, new: str) -> None:
    path = ROOT / relative
    content = updates.get(path, path.read_text(encoding="utf-8"))
    if content.count(old) == 1:
        content = content.replace(old, new, 1)
    elif new in content:
        pass  # second run: previously applied
    else:
        raise RuntimeError(f"Texto esperado nao encontrado uma vez em {relative}: {old[:120]}")
    updates[path] = content

# ----- Backend: additive migration, new users only -----
edit("backend/src/scripts/migrate.ts",
     "      if (fs.existsSync(moderationPath)) await connection.query(fs.readFileSync(moderationPath, 'utf8'));",
     "      if (fs.existsSync(moderationPath)) await connection.query(fs.readFileSync(moderationPath, 'utf8'));\n"
     "      const welcomePath = path.join(path.dirname(schemaPath), 'welcome-screen.sql');\n"
     "      if (fs.existsSync(welcomePath)) await connection.query(fs.readFileSync(welcomePath, 'utf8'));")

edit("backend/src/services/auth.service.ts",
     "      await companyRepository.createInTransaction(\n        connection,\n        createdUserId,",
     "      // Apenas contas criadas apos esta atualizacao recebem a introducao.\n"
     "      await connection.query('INSERT INTO clyvo_welcome (user_id) VALUES (?)', [createdUserId]);\n\n"
     "      await companyRepository.createInTransaction(\n        connection,\n        createdUserId,")

edit("backend/src/services/user.service.ts",
     "import { withTransaction } from '../config/database';",
     "import { withTransaction, execute, queryOne, type RowDataPacket } from '../config/database';")
edit("backend/src/services/user.service.ts",
     "    const [user, company, settings, subscription] = await Promise.all([",
     "    const [user, company, settings, subscription, welcome] = await Promise.all([")
edit("backend/src/services/user.service.ts",
     "      subscriptionRepository.findCurrentByUserId(userId),\n    ]);",
     "      subscriptionRepository.findCurrentByUserId(userId),\n"
     "      queryOne<RowDataPacket>(\n"
     "        `SELECT completed_at, EXISTS(SELECT 1 FROM market_preferences WHERE user_id=?) AS market_configured\n"
     "         FROM clyvo_welcome WHERE user_id=?`, [userId, userId],\n"
     "      ),\n"
     "    ]);")
edit("backend/src/services/user.service.ts",
     "      subscription: subscription ? toPublicSubscription(subscription) : null,",
     "      subscription: subscription ? toPublicSubscription(subscription) : null,\n"
     "      welcome: {\n"
     "        pending: Boolean(welcome && welcome.completed_at === null),\n"
     "        marketConfigured: welcome ? Boolean(welcome.market_configured) : true,\n"
     "      },")
edit("backend/src/services/user.service.ts",
     "export const userService = {",
     "export const userService = {\n"
     "  /** Idempotente. Nao avanca sem as etapas de onboarding/marketplace. */\n"
     "  async completeWelcome(userId: number) {\n"
     "    return withTransaction(async () => {\n"
     "      await userRepository.lock(userId);\n"
     "      const welcome = await queryOne<RowDataPacket>(\n"
     "        'SELECT completed_at FROM clyvo_welcome WHERE user_id=? FOR UPDATE', [userId],\n"
     "      );\n"
     "      if (!welcome || welcome.completed_at !== null) return { completed: true };\n"
     "      const user = await userRepository.findById(userId);\n"
     "      if (!user || !user.onboarding_completed) {\n"
     "        throw AppError.badRequest('Conclua a configuracao inicial antes de continuar.');\n"
     "      }\n"
     "      const market = await queryOne<RowDataPacket>(\n"
     "        'SELECT user_id FROM market_preferences WHERE user_id=?', [userId],\n"
     "      );\n"
     "      if (!market) throw AppError.badRequest('Conclua seu proximo passo antes de acessar o painel.');\n"
     "      await execute(\n"
     "        'UPDATE clyvo_welcome SET completed_at=UTC_TIMESTAMP(3) WHERE user_id=? AND completed_at IS NULL',\n"
     "        [userId],\n"
     "      );\n"
     "      return { completed: true };\n"
     "    });\n"
     "  },\n")

edit("backend/src/controllers/auth.controller.ts",
     "export const authController = {",
     "export const authController = {\n"
     "  async welcome(req: Request, res: Response) {\n"
     "    return sendSuccess(res, await userService.completeWelcome(requireUser(req).id));\n"
     "  },\n")
edit("backend/src/routes/auth.routes.ts",
     "router.get('/me', authenticate, asyncHandler(authController.me));",
     "router.get('/me', authenticate, asyncHandler(authController.me));\n"
     "router.post('/welcome-complete', authenticate, asyncHandler(authController.welcome));")

# ----- Frontend: routing and auth state -----
edit("frontend/src/shared/api/types.ts",
     "export interface Account {\n  user: User;",
     "export interface Account {\n  user: User;\n  welcome?: { pending: boolean; marketConfigured: boolean };")
edit("frontend/src/shared/api/auth.api.ts",
     "  me: () => api.get<Account>('/auth/me'),",
     "  me: () => api.get<Account>('/auth/me'),\n"
     "  completeWelcome: () => api.post<{ completed: boolean }>('/auth/welcome-complete', {}),")

edit("frontend/app/index.tsx",
     "  const { status, user } = useAuth();",
     "  const { status, user, account } = useAuth();")
edit("frontend/app/index.tsx",
     "    router.replace('/(tabs)');",
     "    if (account?.welcome?.pending) {\n"
     "      router.replace(account.welcome.marketConfigured ? '/boas-vindas' : '/mercado/comecar');\n"
     "      return;\n"
     "    }\n\n"
     "    router.replace('/(tabs)');")
edit("frontend/app/index.tsx",
     "  }, [status, user, router]);",
     "  }, [status, user, account, router]);")

edit("frontend/app/(tabs)/_layout.tsx",
     "  const { status, user } = useAuth();",
     "  const { status, user, account } = useAuth();")
edit("frontend/app/(tabs)/_layout.tsx",
     "    if (status === 'autenticado' && user && !user.onboardingCompleted) {\n"
     "      router.replace('/onboarding');\n"
     "    }",
     "    if (status === 'autenticado' && user && !user.onboardingCompleted) {\n"
     "      router.replace('/onboarding');\n"
     "      return;\n"
     "    }\n"
     "    if (status === 'autenticado' && account?.welcome?.pending) {\n"
     "      router.replace(account.welcome.marketConfigured ? '/boas-vindas' : '/mercado/comecar');\n"
     "    }")
edit("frontend/app/(tabs)/_layout.tsx",
     "  }, [status, user, router]);",
     "  }, [status, user, account, router]);\n\n"
     "  // Evita renderizar o painel enquanto a introducao/configuracao esta pendente.\n"
     "  if (status === 'carregando' || (status === 'autenticado' && (!user?.onboardingCompleted || account?.welcome?.pending))) return null;")

edit("frontend/app/mercado/comecar.tsx",
     "import { useRouter } from 'expo-router';",
     "import { useRouter } from 'expo-router';\nimport { useAuth } from '../../src/features/auth/auth-context';")
edit("frontend/app/mercado/comecar.tsx",
     "  const router = useRouter(),\n    action = useAction();",
     "  const router = useRouter(),\n    action = useAction();\n  const { account, reload } = useAuth();")
edit("frontend/app/mercado/comecar.tsx",
     "              acceptRules: accepted.length > 0,\n            });\n            router.replace(",
     "              acceptRules: accepted.length > 0,\n            });\n"
     "            await reload();\n"
     "            if (account?.welcome?.pending) {\n"
     "              router.replace('/boas-vindas');\n"
     "              return;\n"
     "            }\n"
     "            router.replace(")

# Video dependency (SDK 57); regenerate lockfile with npm install after applying.
package = ROOT / "frontend/package.json"
package_json = json.loads(package.read_text(encoding="utf-8"))
if package_json.get("dependencies", {}).get("expo-video") is None:
    package_json["dependencies"]["expo-video"] = "~57.0.4"
    updates[package] = json.dumps(package_json, ensure_ascii=False, indent=2) + "\n"

files_to_write = {
    "database/welcome-screen.sql",
    "frontend/app/boas-vindas.tsx",
    "frontend/src/features/welcome/video-logic.ts",
    "backend/src/scripts/welcome-integration.ts",
}

for relative in files_to_write:
    path = ROOT / relative
    source = (KIT / relative).read_text(encoding="utf-8")
    if path.exists() and path.read_text(encoding="utf-8") != source:
        raise RuntimeError(f"Arquivo ja existe diferente: {relative} (nenhum arquivo alterado)")
    updates[path] = source

# Optional original video. If absent, show text fallback and never ship a fabricated asset.
video_target = ROOT / "frontend/assets/videos/clyvo-boas-vindas.mp4"
if args.video:
    video = args.video.resolve()
    if video.suffix.lower() != '.mp4' or not video.is_file():
        raise RuntimeError("--video precisa apontar para um arquivo .mp4 de verdade")
    if video.stat().st_size < 1024:
        raise RuntimeError("O MP4 parece estar vazio")
else:
    video = video_target if video_target.is_file() else None

source = ROOT / "frontend/src/features/welcome/video-source.ts"
if video:
    updates[source] = ("// Video original da marca. Nao substitua por uma captura de tela.\n"
                       "export const welcomeVideoSource = require('../../../assets/videos/clyvo-boas-vindas.mp4') as number;\n"
                       "export const welcomeVideoAspectRatio = 9 / 16;\n")
else:
    updates[source] = (KIT / "frontend/src/features/welcome/video-source.ts").read_text(encoding="utf-8")

# All preconditions have passed; write the patch atomically per file.
for path, data in updates.items():
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding="utf-8")
if args.video and video != video_target:
    video_target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(video, video_target)

print(f"APLICADO: {len(updates)} arquivos de codigo/configuracao em {ROOT}")
print(f"VIDEO: {'MP4 incorporado' if video else 'nenhum MP4 recebido; fallback textual habilitado'}")
print("SEGUINTE: npm --prefix frontend install && npm --prefix backend run typecheck && npm --prefix frontend run typecheck")
print("A integracao ainda NAO foi publicada. Validar com banco de teste e revisar antes de fazer merge.")
