#!/usr/bin/env python3
"""Install Cly chat on the current Codespaces branch, backing up originals."""
from pathlib import Path
import shutil, sys, datetime
root=Path.cwd()
if not (root/'frontend/app/cly.tsx').exists() or not (root/'backend/src/routes/ai.routes.ts').exists():
    sys.exit('Execute na raiz de Clyvp_Aplicativo; arquivos esperados não encontrados.')
src=Path(__file__).resolve().parent/'files/frontend/app/cly.tsx'
routes=root/'backend/src/routes/ai.routes.ts'
service=root/'backend/src/services/ai.service.ts'
if not service.exists(): sys.exit('Backend Cly não encontrado. Nada foi alterado.')
a=routes.read_text(encoding='utf8'); b=service.read_text(encoding='utf8')
needle="z.enum(['mensagem','descricao','proposta'])"
needle2="generate(userId: number, action: 'mensagem' | 'descricao' | 'proposta', text: string)"
needle3="const tasks = { mensagem: 'Prepare uma mensagem comercial.', descricao: 'Melhore esta descricao.', proposta: 'Prepare um rascunho de proposta, sem inventar valores ou condicoes.' };"
if needle not in a or needle2 not in b or needle3 not in b:
    sys.exit('Sua API Cly é diferente da versão analisada. Instalação cancelada sem modificar arquivos.')
if src.stat().st_size < 1000: sys.exit('Arquivo do chat inválido.')
backup=root/('backup-cly-chat-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
for p in [root/'frontend/app/cly.tsx',routes,service]:
    target=backup/p.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
a=a.replace(needle,"z.enum(['mensagem','descricao','proposta','conversa'])")
b=b.replace(needle2,"generate(userId: number, action: 'mensagem' | 'descricao' | 'proposta' | 'conversa', text: string)")
b=b.replace(needle3,"const tasks = { mensagem: 'Prepare uma mensagem comercial.', descricao: 'Melhore esta descricao.', proposta: 'Prepare um rascunho de proposta, sem inventar valores ou condicoes.', conversa: 'Continue a conversa e ajude o usuário com seu trabalho. Histórico a seguir; responda à última pergunta. Não invente dados.' };")
routes.write_text(a,encoding='utf8');service.write_text(b,encoding='utf8');shutil.copy2(src,root/'frontend/app/cly.tsx')
print('Cly Chat instalado na cópia local do Codespaces.')
print('Backup dos 3 arquivos anteriores em:',backup)
print('A versão da Play Store e o Railway não foram alterados.')
