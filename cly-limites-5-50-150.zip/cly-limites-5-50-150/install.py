#!/usr/bin/env python3
"""Conservative local patcher for Cly quota & UI. No deployment."""
from pathlib import Path
from datetime import datetime
import re, shutil, sys

root = Path.cwd()
quota = root/'backend/src/services/cly-quota.service.ts'
chat = root/'frontend/app/cly.tsx'
if not quota.is_file() or not chat.is_file():
    sys.exit('ERRO: execute na raiz do Clyvp_Aplicativo, onde existem backend/ e frontend/. Nada alterado.')
q = quota.read_text(encoding='utf8')
f = chat.read_text(encoding='utf8')

# Check existence of matching quota view and server-side reservation/finish before any write.
start = q.find('export function quotaView(')
end = q.find('\nasync function locked(', start)
if start < 0 or end < 0:
    sys.exit('ERRO: quotaView/locked nao encontrados. Nenhuma alteracao.')
block = q[start:end]
if 'monthly_used' not in q or 'async reserve(' not in q or 'async finish(' not in q:
    sys.exit('ERRO: controle de cotas inesperado. Nenhuma alteracao.')
# Replace only statements in the quotaView body
patterns = [
 (r"const\s+paid\s*=\s*[^;]+;\s*const\s+limit\s*=\s*[^;]+;", "const limit = plan === 'pro_max' ? 150 : plan === 'pro' ? 50 : 5;"),
 (r"const\s+used\s*=\s*[^;]+;", "const used = row.monthly_used;"),
 (r"const\s+reset\s*=\s*[^;]+;", "const reset = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));"),
 (r"blocked:\s*paid\s*\?[^,]+,", "blocked: used >= limit,"),
]
for pattern, repl in patterns:
    block, count = re.subn(pattern, repl, block, count=1)
    if count != 1:
        sys.exit('ERRO: formato de quotaView inesperado: ' + pattern + '. Nenhuma alteracao.')
# clean up left-over free cooldown mutation in finish. The monthly usage is the single source of truth.
newq = q[:start] + block + q[end:]
finish_start = newq.find(' async finish(')
if finish_start < 0:
    sys.exit('ERRO: finish nao encontrado. Nenhuma alteracao.')
part = newq[finish_start:]
free_match = re.search(r"\n\s*if\s*\(plan\s*===\s*'free'\)\s*\{", part)
if free_match:
    a = finish_start + free_match.start()
    op = newq.index('{', finish_start + free_match.start())
    depth = 0
    close = None
    for i in range(op, len(newq)):
        if newq[i] == '{': depth += 1
        elif newq[i] == '}':
            depth -= 1
            if depth == 0:
                close = i + 1
                break
    if close is None: sys.exit('ERRO: bloco free incompleto. Nenhuma alteracao.')
    newq = newq[:a] + newq[close:]
# Once free cooldown is removed, the former plan and clock in finish may become unused.
newq = newq[:finish_start] + newq[finish_start:].replace(
    'async finish(userId: number, token: string, plan: string, success: boolean)',
    'async finish(userId: number, token: string, _plan: string, success: boolean)', 1
).replace('const { row, now } = await locked(userId);', 'const { row } = await locked(userId);', 1)
# No modifications to consent, lease and token validation.
if 'if (view.blocked)' not in newq or 'row.monthly_used++' not in newq:
    sys.exit('ERRO: protecao de cota ausente. Nenhuma alteracao.')

component_path = root/'frontend/src/features/cly/ClyQuotaNotice.tsx'
component = r'''import { useCallback, useState } from 'react';
import { useFocusEffect, useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { api } from '../../shared/api/client';
import { theme, useThemeMode } from '../../shared/theme';

type Quota = {
  planCode: string;
  limit: number;
  used: number;
  remaining: number;
  blocked: boolean;
  resetsAt: string | null;
};

export function ClyQuotaNotice() {
  useThemeMode();
  const router = useRouter();
  const [quota, setQuota] = useState<Quota | null>(null);
  const load = useCallback(async () => {
    try {
      const result = await api.get<{ quota: Quota }>('/ai/status');
      setQuota(result.quota);
    } catch { setQuota(null); }
  }, []);
  useFocusEffect(useCallback(() => {
    void load();
    // Atualiza o saldo apos mensagens enviadas no mesmo chat.
    const interval = setInterval(() => { void load(); }, 12000);
    return () => clearInterval(interval);
  }, [load]));
  if (!quota) return null;
  const free = quota.planCode === 'free';
  const plan = quota.planCode === 'pro_max' ? 'Pro Plus' : free ? 'Free' : 'Pro';
  const date = quota.resetsAt ? new Date(quota.resetsAt).toLocaleDateString('pt-BR') : null;
  return (
    <View style={styles.container}>
      <View style={styles.head}>
        <Text style={[styles.title, { color: theme.colors.text }]}>Cly • Plano {plan}</Text>
        <Text style={styles.number}>{quota.remaining}/{quota.limit}</Text>
      </View>
      <Text style={[styles.detail, { color: theme.colors.textSecondary }]}>
        {quota.remaining === 0 ? 'Você atingiu o limite de mensagens deste mês.' :
          `${quota.remaining} mensagem${quota.remaining === 1 ? '' : 's'} restante${quota.remaining === 1 ? '' : 's'} neste mês.`}
        {date ? ` Renova em ${date}.` : ''}
      </Text>
      {free && quota.blocked ? (
        <Pressable accessibilityRole="button" onPress={() => router.push('/planos')} style={styles.button}>
          <Text style={styles.buttonText}>Conhecer Pro e Pro Plus</Text>
        </Pressable>
      ) : free ? <Text style={styles.promo}>Gostou da Cly? O Pro oferece 50 mensagens mensais!</Text> : null}
    </View>
  );
}
const styles = StyleSheet.create({
  container: { borderWidth: 1, borderColor: '#f4b48b', borderRadius: 14, padding: 12, marginVertical: 8, gap: 6 },
  head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  title: { fontSize: 14, fontWeight: '700' },
  number: { color: '#ef701f', fontSize: 15, fontWeight: '800' },
  detail: { fontSize: 12, lineHeight: 18 },
  promo: { color: '#cb6726', fontSize: 12 },
  button: { backgroundColor: '#e96e21', paddingVertical: 10, borderRadius: 9, alignItems: 'center', marginTop: 4 },
  buttonText: { color: '#fff', fontWeight: '700' },
});
'''
# Import + JSX injection at root. We can inject into known Cly main return roots safely.
imports = "import { ClyQuotaNotice } from '../src/features/cly/ClyQuotaNotice';\n"
newf = f if 'ClyQuotaNotice' in f else imports + f
if 'ClyQuotaNotice' not in f:
    # Locate component render return: use last 'return (' or 'return <' before stylesheet declaration.
    pos = newf.find('export default function ClyScreen(')
    if pos < 0:
        sys.exit('ERRO: componente ClyScreen inesperado. Nenhuma alteracao.')
    boundary = newf.find('const styles', pos)
    if boundary < 0: boundary = len(newf)
    content = newf[pos:boundary]
    # Try root <Screen>, <View>, <KeyboardAvoidingView>, <SafeAreaView> or <LinearGradient>
    matches = list(re.finditer(r'\breturn\s*(?:\(\s*)?<([A-Z][A-Za-z0-9_.]*)\b',content))
    if not matches:
        sys.exit('ERRO: nao foi possivel localizar a tela do chat sem risco. Nenhuma alteracao.')
    match = matches[-1]
    tag = match.group(1)
    if tag not in {'View','Screen','KeyboardAvoidingView','SafeAreaView','ScrollView','LinearGradient'}:
        sys.exit(f'ERRO: tela usa raiz <{tag}>. Nao alterei para evitar danos; encaminhe as primeiras 100 linhas de frontend/app/cly.tsx.')
    # Find closing > for JSX opening root while respecting expressions / strings
    tagbeg = pos + match.end()  # after root tag name
    brace = 0
    string = None
    opening_end = None
    for i in range(tagbeg, min(tagbeg+1500, len(newf))):
        ch=newf[i]
        if string:
            if ch == string and newf[i-1] != '\\': string=None
        elif ch in ('"',"'",'`'): string=ch
        elif ch=='{': brace+=1
        elif ch=='}': brace-=1
        elif ch=='>' and brace==0:
            opening_end=i+1
            break
    if opening_end is None or newf[opening_end-2]=='/':
        sys.exit('ERRO: elemento principal da tela inesperado. Nenhuma alteracao.')
    newf=newf[:opening_end]+"\n      <ClyQuotaNotice />"+newf[opening_end:]

# Prevent duplicated quotas if current local chat already displays quota: visual duplication is tolerable, but avoid specific status mutation.
backup = root / ('backup-cly-limites-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir()
for p in [quota,chat]:
    shutil.copy2(p,backup/p.name)
if component_path.exists(): shutil.copy2(component_path, backup/component_path.name)
component_path.parent.mkdir(parents=True, exist_ok=True)
quota.write_text(newq,encoding='utf8')
chat.write_text(newf,encoding='utf8')
component_path.write_text(component, encoding='utf8')
print('SUCESSO: limites mensais Free=5 Pro=50 Pro Plus=150 no backend e aviso no chat.')
print('Backup:',backup)
print('Nao houve deploy no Railway e nao foram alteradas assinaturas de usuarios.')
print('Execute: npm --prefix frontend run typecheck && npm --prefix backend run typecheck')
