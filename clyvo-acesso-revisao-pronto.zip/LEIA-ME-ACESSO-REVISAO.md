# Clyvo — cortesia para conta de demonstração

Este pacote PREPARA a liberação. Não ativa contas nem modifica o Railway sozinho.
Use uma conta dedicada com dados fictícios. O acesso é ao mesmo Pro Plus oferecido
aos usuários; não há detecção de avaliadores nem ocultação de funcionalidades.

## Instalação
1. Faça backup do projeto.
2. Copie os arquivos de backend/src deste pacote para o backend do projeto.
   Não substitua .env, package.json, package-lock.json ou banco de dados.
3. Dentro de backend, execute:
   npm run typecheck
   node --import tsx src/scripts/review-access.test.ts
   npm run build
4. Envie a alteração ao GitHub e aguarde o deploy da API no Railway.
   Só então ative a cortesia. A versão antiga da API não preserva a cortesia.
Não há migração de banco; são utilizadas colunas já existentes.

## Ativação — no ambiente da API com acesso ao banco de produção
Os comandos seguintes devem rodar dentro do backend no ambiente correto, com
as variáveis privadas já configuradas. Não copie segredos para o chat.
Substitua EMAIL pelo endereço da conta dedicada:
   node dist/scripts/review-access.js status EMAIL

Confira o e-mail e o userId retornados. Então, substitua ID pelo userId:
   node dist/scripts/review-access.js grant EMAIL ID

O script exige simultaneamente e-mail e ID existentes. Não cria usuário nem
senha. Recusa contas pagas, inativas ou vinculadas a provedores de cobrança.
A cortesia permanece ativa até revogação ou exclusão da conta. Não cancela
compras, não cria compra fictícia e não libera privilégios de moderação.
Após ativar, saia e entre no Clyvo e confira plano, limites e acesso às funções.
Teste também Atualizar assinatura: a cortesia deve permanecer.

## Remoção
   node dist/scripts/review-access.js revoke EMAIL ID
A conta retorna ao Free. Seus dados não são removidos.

## Validação e pendências
A verificação de elegibilidade e a compilação são locais. Não houve teste com
o banco de produção, RevenueCat real ou compra Android neste pacote.
Teste login, criação de cliente/proposta e PDF na conta dedicada após ativar.
A Cly continua indisponível se o provedor não estiver configurado; essa cortesia
não ativa IA, pagamento ou outros serviços externos.
Informe o acesso de demonstração nas instruções do Play Console somente após
testar. Esta mudança não resolve outras pendências de publicação.

Arquivos novos: review-access.ts (serviço e script), review-access.test.ts.
Arquivo alterado: services/billing.service.ts (preserva cortesia ativa antes
da consulta remota e novamente dentro da transação).
